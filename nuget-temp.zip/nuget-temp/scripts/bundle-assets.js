const fs = require('fs');
const path = require('path');

/**
 * Script to prepare asset directories
 * Note: Webpack bundles all dependencies automatically, so we don't need to copy assets manually
 */
async function bundleAssets() {
  const extensionRoot = path.resolve(__dirname, '..');
  const assetsPath = path.join(extensionRoot, 'assets');
  const outPath = path.join(extensionRoot, 'out');

  console.log('Preparing asset directories...');

  // Ensure directories exist
  if (!fs.existsSync(assetsPath)) {
    fs.mkdirSync(assetsPath, { recursive: true });
    console.log('✓ Created assets directory');
  }

  if (!fs.existsSync(outPath)) {
    fs.mkdirSync(outPath, { recursive: true });
    console.log('✓ Created out directory');
  }

  console.log('Asset preparation complete!');
  console.log('Note: Webpack will bundle all required dependencies automatically.');
}

// Run if called directly
if (require.main === module) {
  bundleAssets().catch(console.error);
}

module.exports = { bundleAssets };
