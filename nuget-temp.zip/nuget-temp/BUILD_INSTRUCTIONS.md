# Build Instructions for NuGet Dependency Graph Extension

## Prerequisites

1. **Node.js** (v16 or higher) - [Download](https://nodejs.org/)
2. **.NET SDK** (v7.0 or higher) - [Download](https://dotnet.microsoft.com/download)
3. **VS Code** (v1.74.0 or higher) - [Download](https://code.visualstudio.com/)

## Installation

### 1. Install Dependencies

```bash
npm install
```

This will install all required packages including:
- React and React-DOM for the UI
- react-force-graph-3d for 3D visualization
- Three.js for WebGL rendering
- TypeScript and webpack for compilation

### 2. Build the Extension

```bash
npm run compile
```

This runs three steps:
1. `bundle:assets` - Prepares asset directories
2. `compile:extension` - Builds the VS Code extension (backend)
3. `compile:webview` - Builds the React webview (frontend)

### 3. Package for Distribution (Optional)

```bash
npm run package
```

This creates an optimized production build with minification and source maps.

## Development Workflow

### Watch Mode

For active development, use watch mode to automatically rebuild on file changes:

```bash
# Watch both extension and webview
npm run watch

# Or watch individually
npm run watch:extension  # Backend only
npm run watch:webview    # Frontend only
```

### Debugging

1. Open the project in VS Code
2. Press `F5` to launch the Extension Development Host
3. Open a .NET project with a `.csproj` file
4. Right-click the `.csproj` file and select:
   - "Visualize NuGet Dependencies" - Show all dependencies
   - "Visualize NuGet Vulnerabilities" - Show security vulnerabilities
   - "Visualize Full NuGet Dependency Graph" - Show complete graph with transitive deps

### Testing

```bash
npm test           # Run all tests
npm run lint       # Check code quality
```

## Project Structure

```
src/
├── extension.ts                    # Extension entry point
├── providers/
│   └── nugetDependencyProvider.ts  # Dependency analysis logic
├── services/
│   ├── dotnetCliService.ts         # .NET CLI integration
│   ├── vulnerabilityScanner.ts     # Security scanning
│   └── projectFileParser.ts        # .csproj parsing
├── webview/
│   ├── webviewManager.ts           # VS Code webview management
│   ├── index.tsx                   # React app entry
│   ├── App.tsx                     # Main React component
│   ├── styles.css                  # Global styles
│   └── components/
│       ├── ForceGraphRenderer.tsx  # 3D graph visualization
│       ├── InfoPanel.tsx           # Package details sidebar
│       └── ErrorBoundary.tsx       # Error handling
└── types/
    └── dependency.ts               # TypeScript interfaces

out/
├── extension.js                    # Compiled extension
└── webview.js                      # Compiled React app
```

## Build Output

After building, the following files are generated:

- `out/extension.js` - Main extension code (runs in Node.js)
- `out/webview.js` - React webview bundle (runs in browser context)
- `out/webview.js.map` - Source map for debugging

## Troubleshooting

### "webpack: command not found"

Install dependencies first:
```bash
npm install
```

### "Cannot find module './webview/webviewManager'"

Run the build:
```bash
npm run compile
```

### Graph doesn't display

1. Check if the project has NuGet packages:
   ```bash
   dotnet list <project.csproj> package
   ```

2. Verify .NET SDK is installed:
   ```bash
   dotnet --version
   ```

3. Check the VS Code Developer Console (Help > Toggle Developer Tools) for errors

### TypeScript errors

The build uses `transpileOnly: true` for faster compilation. To see full type errors:
```bash
npx tsc --noEmit
```

## Required Dependencies

The extension requires these key npm packages (installed via `npm install`):

- **react** & **react-dom**: UI framework
- **react-force-graph-3d**: 3D graph visualization
- **three**: 3D rendering engine
- **d3-force**: Physics simulation for graph layout
- **xml2js**: .csproj file parsing
- **typescript**: Language support
- **webpack**: Module bundler
- **ts-loader**: TypeScript compilation in webpack

## How It Works

1. **Extension Activation**: When you right-click a `.csproj` file, the extension activates
2. **Dependency Analysis**:
   - Runs `dotnet list package --format json` to get dependencies
   - Optionally runs `dotnet list package --vulnerable` for security scanning
   - Falls back to parsing `.csproj` XML if .NET CLI unavailable
3. **Graph Generation**: Creates nodes (packages) and links (dependencies)
4. **Webview Rendering**:
   - Opens a VS Code webview panel
   - Loads the React app with graph data
   - Renders interactive 3D visualization using force-graph-3d

## Next Steps

After building, you can:

1. **Run in Development**: Press `F5` in VS Code
2. **Package as VSIX**: Run `vsce package` (requires `npm install -g @vscode/vsce`)
3. **Publish**: Run `vsce publish` (requires publisher account)

## Support

For issues or questions:
- Check the [GitHub Issues](https://github.com/nuget-tools/nuget-dependency-graph/issues)
- Review the [requirements doc](.kiro/specs/webview-rendering-fix/requirements.md)
- Enable verbose logging in VS Code settings
