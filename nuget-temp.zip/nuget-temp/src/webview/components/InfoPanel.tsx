import React from 'react';
import { GraphNode, DependencyAnalysisResult } from '../../types/dependency';

interface InfoPanelProps {
  selectedNode: GraphNode | null;
  onClose: () => void;
  data: DependencyAnalysisResult;
  mode: string;
}

export const InfoPanel: React.FC<InfoPanelProps> = ({
  selectedNode,
  onClose,
  data,
  mode
}) => {
  if (!selectedNode) {
    // Show summary panel
    return (
      <div className="info-panel">
        <div className="info-panel-header">
          <h2>{data.projectName}</h2>
        </div>
        <div className="info-panel-content">
          <div className="summary-section">
            <h3>Summary</h3>
            <div className="summary-item">
              <span className="summary-label">Total Packages:</span>
              <span className="summary-value">{data.graphData.nodes.length}</span>
            </div>
            <div className="summary-item">
              <span className="summary-label">Dependencies:</span>
              <span className="summary-value">{data.graphData.links.length}</span>
            </div>
            {data.vulnerabilityCount && data.vulnerabilityCount.total > 0 && (
              <>
                <div className="summary-item vulnerability-summary">
                  <span className="summary-label">Vulnerabilities:</span>
                  <span className="summary-value critical">{data.vulnerabilityCount.total}</span>
                </div>
                {data.vulnerabilityCount.critical > 0 && (
                  <div className="summary-item vulnerability-detail">
                    <span className="vuln-badge critical">Critical: {data.vulnerabilityCount.critical}</span>
                  </div>
                )}
                {data.vulnerabilityCount.high > 0 && (
                  <div className="summary-item vulnerability-detail">
                    <span className="vuln-badge high">High: {data.vulnerabilityCount.high}</span>
                  </div>
                )}
                {data.vulnerabilityCount.moderate > 0 && (
                  <div className="summary-item vulnerability-detail">
                    <span className="vuln-badge moderate">Moderate: {data.vulnerabilityCount.moderate}</span>
                  </div>
                )}
                {data.vulnerabilityCount.low > 0 && (
                  <div className="summary-item vulnerability-detail">
                    <span className="vuln-badge low">Low: {data.vulnerabilityCount.low}</span>
                  </div>
                )}
              </>
            )}
          </div>
          <div className="help-section">
            <h3>Controls</h3>
            <ul>
              <li>Click a node to view package details</li>
              <li>Drag to rotate the graph</li>
              <li>Scroll to zoom in/out</li>
              <li>Right-click + drag to pan</li>
            </ul>
          </div>
        </div>
      </div>
    );
  }

  // Show selected node details
  return (
    <div className="info-panel">
      <div className="info-panel-header">
        <h2>{selectedNode.name}</h2>
        <button className="close-button" onClick={onClose}>×</button>
      </div>
      <div className="info-panel-content">
        <div className="detail-section">
          <div className="detail-item">
            <span className="detail-label">Version:</span>
            <span className="detail-value">{selectedNode.version}</span>
          </div>
          <div className="detail-item">
            <span className="detail-label">Type:</span>
            <span className="detail-value">
              {selectedNode.isRoot ? 'Direct Dependency' : 'Transitive'}
            </span>
          </div>
          {selectedNode.depth !== undefined && (
            <div className="detail-item">
              <span className="detail-label">Depth:</span>
              <span className="detail-value">{selectedNode.depth}</span>
            </div>
          )}
        </div>

        {selectedNode.vulnerabilities && selectedNode.vulnerabilities.length > 0 && (
          <div className="vulnerabilities-section">
            <h3>Vulnerabilities ({selectedNode.vulnerabilities.length})</h3>
            {selectedNode.vulnerabilities.map((vuln, index) => (
              <div key={index} className={`vulnerability-card ${vuln.severity.toLowerCase()}`}>
                <div className="vuln-header">
                  <span className={`vuln-severity ${vuln.severity.toLowerCase()}`}>
                    {vuln.severity}
                  </span>
                </div>
                <div className="vuln-title">{vuln.title || 'Unknown Vulnerability'}</div>
                {vuln.description && (
                  <div className="vuln-description">{vuln.description}</div>
                )}
                {vuln.advisoryUrl && (
                  <div className="vuln-link">
                    <a href={vuln.advisoryUrl} target="_blank" rel="noopener noreferrer">
                      View Advisory →
                    </a>
                  </div>
                )}
                {vuln.cve && vuln.cve.length > 0 && (
                  <div className="vuln-cve">
                    <strong>CVE:</strong> {vuln.cve.join(', ')}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {(!selectedNode.vulnerabilities || selectedNode.vulnerabilities.length === 0) && mode === 'vulnerabilities' && (
          <div className="no-vulnerabilities">
            <p>No known vulnerabilities</p>
          </div>
        )}
      </div>
    </div>
  );
};
