import React, { useEffect, useRef, useState } from 'react';
import ForceGraph3D from 'react-force-graph-3d';
import { GraphData, GraphNode, GraphLink } from '../../types/dependency';

interface ForceGraphRendererProps {
  data: GraphData;
  mode: 'dependencies' | 'vulnerabilities' | 'full';
  onNodeClick: (node: GraphNode) => void;
}

export const ForceGraphRenderer: React.FC<ForceGraphRendererProps> = ({
  data,
  mode,
  onNodeClick
}) => {
  const graphRef = useRef<any>();
  const [dimensions, setDimensions] = useState({
    width: window.innerWidth,
    height: window.innerHeight
  });

  useEffect(() => {
    const handleResize = () => {
      setDimensions({
        width: window.innerWidth,
        height: window.innerHeight
      });
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    // Auto-fit graph when data loads
    if (graphRef.current) {
      setTimeout(() => {
        graphRef.current?.zoomToFit(400);
      }, 100);
    }
  }, [data]);

  const handleNodeClick = (node: any) => {
    if (node && typeof node === 'object') {
      onNodeClick(node as GraphNode);
    }
  };

  const getNodeLabel = (node: any): string => {
    if (!node) return '';
    return `${node.name || node.id || 'Unknown'}\n${node.version || ''}`;
  };

  const getNodeColor = (node: any): string => {
    if (!node) return '#999999';

    // Use the color assigned by the provider
    if (node.color) {
      return node.color;
    }

    // Fallback colors
    if (mode === 'vulnerabilities' && node.vulnerabilities?.length > 0) {
      return '#ff4444';
    }

    return node.isRoot ? '#4dabf7' : '#999999';
  };

  const getLinkColor = (link: any): string => {
    if (!link) return 'rgba(255,255,255,0.2)';
    return link.color || 'rgba(255,255,255,0.2)';
  };

  const getLinkWidth = (link: any): number => {
    if (!link) return 1;
    return link.value || 1;
  };

  // Log data for debugging
  useEffect(() => {
    console.log('[ForceGraphRenderer] Rendering graph with:', {
      nodes: data.nodes.length,
      links: data.links.length,
      mode
    });
  }, [data, mode]);

  return (
    <div style={{ width: '100%', height: '100%' }}>
      {data.nodes.length === 0 ? (
        <div className="no-data">
          <p>No packages to display</p>
          <p style={{ fontSize: '12px', color: 'var(--vscode-descriptionForeground)', marginTop: '10px' }}>
            This project may not have any NuGet package references.
          </p>
        </div>
      ) : (
        <ForceGraph3D
          ref={graphRef}
          graphData={data}
          width={dimensions.width}
          height={dimensions.height}
          backgroundColor="rgba(0,0,0,0)"
          nodeLabel={getNodeLabel}
          nodeColor={getNodeColor}
          nodeVal={(node: any) => node.val || 1}
          nodeRelSize={6}
          linkColor={getLinkColor}
          linkWidth={getLinkWidth}
          linkOpacity={0.6}
          onNodeClick={handleNodeClick}
          enableNodeDrag={true}
          enableNavigationControls={true}
          showNavInfo={false}
          d3VelocityDecay={0.3}
          cooldownTime={3000}
        />
      )}
    </div>
  );
};
