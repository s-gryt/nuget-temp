import * as vscode from 'vscode';
import * as path from 'path';
import { DependencyAnalysisResult } from '../types/dependency';

export class WebviewManager {
  private panel: vscode.WebviewPanel | undefined;
  private readonly context: vscode.ExtensionContext;

  constructor(context: vscode.ExtensionContext) {
    this.context = context;
  }

  async showDependencyGraph(
    data: DependencyAnalysisResult,
    mode: 'dependencies' | 'vulnerabilities' | 'full'
  ): Promise<void> {
    if (this.panel) {
      // Reuse existing panel
      this.panel.reveal(vscode.ViewColumn.One);
    } else {
      // Create new panel
      this.panel = vscode.window.createWebviewPanel(
        'nugetDependencyGraph',
        'NuGet Dependency Graph',
        vscode.ViewColumn.One,
        {
          enableScripts: true,
          retainContextWhenHidden: true,
          localResourceRoots: [
            vscode.Uri.file(path.join(this.context.extensionPath, 'out')),
            vscode.Uri.file(path.join(this.context.extensionPath, 'media'))
          ]
        }
      );

      // Handle panel disposal
      this.panel.onDidDispose(() => {
        this.panel = undefined;
      }, null, this.context.subscriptions);
    }

    // Update panel title based on mode
    this.panel.title = this.getTitleForMode(mode, data.projectName);

    // Set webview HTML content
    this.panel.webview.html = this.getWebviewContent(data, mode);

    // Handle messages from webview
    this.panel.webview.onDidReceiveMessage(
      message => {
        switch (message.type) {
          case 'error':
            vscode.window.showErrorMessage(`Webview Error: ${message.message}`);
            break;
          case 'log':
            console.log(`[Webview]: ${message.message}`);
            break;
          case 'ready':
            console.log('[Webview]: Ready to receive data');
            break;
        }
      },
      null,
      this.context.subscriptions
    );
  }

  private getTitleForMode(mode: string, projectName: string): string {
    switch (mode) {
      case 'vulnerabilities':
        return `Vulnerabilities - ${projectName}`;
      case 'full':
        return `Full Graph - ${projectName}`;
      default:
        return `Dependencies - ${projectName}`;
    }
  }

  private getWebviewContent(data: DependencyAnalysisResult, mode: string): string {
    const nonce = this.getNonce();

    // Get URIs for bundled scripts (will be created by webpack)
    const scriptUri = this.panel?.webview.asWebviewUri(
      vscode.Uri.file(path.join(this.context.extensionPath, 'out', 'webview.js'))
    );

    // Serialize data for webview
    const serializedData = JSON.stringify(data);
    const serializedMode = JSON.stringify(mode);

    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Security-Policy"
          content="default-src 'none';
                   style-src ${this.panel?.webview.cspSource} 'unsafe-inline';
                   script-src 'nonce-${nonce}' 'unsafe-eval';
                   img-src ${this.panel?.webview.cspSource} https: data:;
                   connect-src https:;">
    <title>NuGet Dependency Graph</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: var(--vscode-editor-background);
            color: var(--vscode-editor-foreground);
            font-family: var(--vscode-font-family);
        }
        #root {
            width: 100vw;
            height: 100vh;
        }
        .loading {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            font-size: 18px;
        }
        .loading-spinner {
            width: 50px;
            height: 50px;
            border: 5px solid var(--vscode-progressBar-background);
            border-top: 5px solid var(--vscode-button-background);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-bottom: 20px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .error {
            padding: 20px;
            color: var(--vscode-errorForeground);
            background-color: var(--vscode-inputValidation-errorBackground);
            border: 1px solid var(--vscode-inputValidation-errorBorder);
            margin: 20px;
            border-radius: 4px;
        }
        .error h2 {
            margin-top: 0;
        }
        .error-details {
            margin-top: 10px;
            font-family: var(--vscode-editor-font-family);
            font-size: 12px;
            white-space: pre-wrap;
            background-color: var(--vscode-editor-background);
            padding: 10px;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div id="root">
        <div class="loading">
            <div class="loading-spinner"></div>
            <div>Loading dependency graph...</div>
        </div>
    </div>

    <script nonce="${nonce}">
        // Global error handler
        window.addEventListener('error', (event) => {
            console.error('[Global Error]:', event.error);
            document.getElementById('root').innerHTML = \`
                <div class="error">
                    <h2>Failed to Load Dependency Graph</h2>
                    <p>\${event.error?.message || 'Unknown error occurred'}</p>
                    <div class="error-details">\${event.error?.stack || ''}</div>
                </div>
            \`;
        });

        // Pass data from extension to React app
        window.__NUGET_DATA__ = ${serializedData};
        window.__NUGET_MODE__ = ${serializedMode};

        console.log('[Webview] Data loaded:', {
            nodes: window.__NUGET_DATA__?.graphData?.nodes?.length,
            links: window.__NUGET_DATA__?.graphData?.links?.length,
            mode: window.__NUGET_MODE__
        });
    </script>

    <script nonce="${nonce}" src="${scriptUri}"></script>
</body>
</html>`;
  }

  private getNonce(): string {
    let text = '';
    const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    for (let i = 0; i < 32; i++) {
      text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
  }

  public dispose(): void {
    if (this.panel) {
      this.panel.dispose();
      this.panel = undefined;
    }
  }
}
