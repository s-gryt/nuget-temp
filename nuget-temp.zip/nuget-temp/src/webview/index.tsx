import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from './App';

// This will be injected by webviewManager
declare global {
  interface Window {
    __NUGET_DATA__: any;
    __NUGET_MODE__: string;
  }
}

// Initialize React app
const root = document.getElementById('root');
if (root) {
  try {
    const reactRoot = ReactDOM.createRoot(root);
    reactRoot.render(
      <React.StrictMode>
        <App
          data={window.__NUGET_DATA__}
          mode={window.__NUGET_MODE__}
        />
      </React.StrictMode>
    );
  } catch (error) {
    console.error('[React Error]:', error);
    root.innerHTML = `
      <div class="error">
        <h2>Failed to Initialize React Application</h2>
        <p>${error instanceof Error ? error.message : String(error)}</p>
      </div>
    `;
  }
} else {
  console.error('[Critical] Root element not found');
}
