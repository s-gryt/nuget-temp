import React, { useState, useEffect } from 'react';
import { DependencyAnalysisResult } from '../types/dependency';
import { ForceGraphRenderer } from './components/ForceGraphRenderer';
import { InfoPanel } from './components/InfoPanel';
import { ErrorBoundary } from './components/ErrorBoundary';
import './styles.css';

interface AppProps {
  data: DependencyAnalysisResult;
  mode: 'dependencies' | 'vulnerabilities' | 'full';
}

export const App: React.FC<AppProps> = ({ data, mode }) => {
  const [selectedNode, setSelectedNode] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Validate data
    if (!data) {
      setError('No data provided to React app');
      console.error('[App] No data in window.__NUGET_DATA__');
      return;
    }

    if (!data.graphData) {
      setError('Invalid data structure: missing graphData');
      console.error('[App] Data structure:', data);
      return;
    }

    if (!data.graphData.nodes || data.graphData.nodes.length === 0) {
      setError('No packages found in the project');
      console.warn('[App] Empty nodes array. Project may have no NuGet packages.');
      console.log('[App] Full data:', JSON.stringify(data, null, 2));
      return;
    }

    console.log('[App] Initialized successfully with:', {
      nodes: data.graphData.nodes.length,
      links: data.graphData.links.length,
      mode,
      projectName: data.projectName,
      sampleNodes: data.graphData.nodes.slice(0, 3)
    });
  }, [data, mode]);

  if (error) {
    return (
      <div className="error-container">
        <div className="error">
          <h2>Unable to Display Graph</h2>
          <p>{error}</p>
          <div className="error-help">
            <p>Possible reasons:</p>
            <ul>
              <li>The project has no NuGet package references</li>
              <li>The .csproj file could not be parsed</li>
              <li>The .NET CLI is not available</li>
            </ul>
          </div>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <div className="app-container">
        <div className="graph-container">
          <ForceGraphRenderer
            data={data.graphData}
            mode={mode}
            onNodeClick={setSelectedNode}
          />
        </div>
        <InfoPanel
          selectedNode={selectedNode}
          onClose={() => setSelectedNode(null)}
          data={data}
          mode={mode}
        />
      </div>
    </ErrorBoundary>
  );
};
